package s2;

/**
 *
 * @author Jesús López
 */
public enum Opciones_Secundario { ADD_DETALLE, BORRAR_DETALLES, CANCELAR_PEDIDO,
FINALIZAR_PEDIDO}
